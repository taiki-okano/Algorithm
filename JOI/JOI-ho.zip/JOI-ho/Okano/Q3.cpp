#include <iostream>
#include <algorithm>

constexpr int MAX_NM = 3000;

int N, M;
char map[MAX_NM][MAX_NM];
int nmap[MAX_NM][MAX_NM] = {}; //3 : right and down, 2 : right, 1 : down

int dfs(int n, int m);

int main(){

	int N, M; 
	
	std::cin >> N >> M;

	for(int i = 0; i < N; ++i){
		for(int j = 0; j < M; ++j){
			std::cin >> map[i][j];
		
			if(i > 2 && j > 2){
				if(map[i][j] == 'W' &&
						map[i - 1][j] == 'G' &&
						map[i - 2][j] == 'R'
						)
				{
					nmap[i - 2][j] += 1;
				}
				if(map[i][j] == 'W' &&
						map[i][j - 1] == 'G' &&
						map[i][j - 2] == 'R'
						)
				{
					nmap[i][j - 2] += 2;
				}
			}
		}
	}

	int ans = 0;
	for(int i = 0; i < std::max(N, M); ++i){
		int n = N - 1 - i, m = M - 1;

		for(int j = 0; j < i; ++i, ++n, --m){
            if((i < 2 && j < 2) || i >= N || j >= M){
                continue;
            }

            if(nmap[i][j] > 0){
                ++ans;
            
                if(nmap[i][j] == 1){
                    nmap[i - 1][j + 1] -= 2;
                    nmap[i - 2][j + 2] -= 2;
                }
                if(nmap[i][j] == 2){
                    nmap[i + 1][j - 1] -= 1;
                    nmap[i + 2][j - 2] -= 1;
                }
                if(nmap[i][j] == 3){
                    nmap[i - 1][j + 1] -= 2;
                    nmap[i - 2][j + 2] -= 2;
                }
		}
	}

	std::cout << ans << std::endl;

	return 0;
}
