#include <iostream>
#include <algorithm>
#include <vector>
#include <functional>

int main(){

	int N, K;
	std::vector<long long> in;
	std::vector<long long> diff;

	std::cin >> N >> K;
	--K;

	for(int i = 0; i < N; ++i){
		int input;
		std::cin >> input;

		in.push_back(input);
		if(i > 0){
			diff.push_back(in[i] - (in[i - 1] + 1));
		}
	}

	int ans = (in[N - 1] + 1) - in[0];

	std::sort(diff.begin(), diff.end(), std::greater<int>());

	for(int i = 0; i < K; ++i){
		ans -= diff[i];
	}

	std::cout << ans << std::endl;

	return 0;
}
