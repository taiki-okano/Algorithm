#include <iostream>
#include <algorithm>

constexpr int MAX_NM = 3000;

int N, M;
char map[MAX_NM][MAX_NM];
int nmap[MAX_NM][MAX_NM] = {}; //3 : right and down, 2 : right, 1 : down

int main(){

	std::cin >> N >> M;

	for(int i = 0; i < N; ++i){
		for(int j = 0; j < M; ++j){
			std::cin >> map[i][j];
		
			if(i > 1 &&
					map[i][j] == 'W' &&
					map[i - 1][j] == 'G' &&
					map[i - 2][j] == 'R'
					)
			{
				nmap[i][j] += 1;
			}
			if(j > 1 &&
					map[i][j] == 'W' &&
					map[i][j - 1] == 'G' &&
					map[i][j - 2] == 'R'
					)
			{
				nmap[i][j] += 2;
			}
		}
	}

	int ans = 0;
	for(int i = 0; i < N; ++i){
		for(int j = 0; j < M; ++j){
			if((i < 2 && j < 2) || i >= N || j >= M){
				continue;
			}

			if(nmap[i][j] > 0){
				++ans;
			
				if(nmap[i][j] == 1){
					if(j < M - 1){
						nmap[i - 1][j + 1] -= 2;
					}
					if(j < M - 2){
						nmap[i - 2][j + 2] -= 2;
					}
				}
				if(nmap[i][j] == 2){
					if(i < N - 1){
						nmap[i + 1][j - 1] -= 1;
					}
					if(i < N - 2 ){
						nmap[i + 2][j - 2] -= 1;
					}
				}
				if(nmap[i][j] == 3){
					bool right = false;
					for(int k = 1; i + k < N && j - k > 1; ++k){
						if(nmap[i + k][j - k] == 2){

							right = true;
							break;
						}
						if(nmap[i + k][j - k] == 1){
							break;
						}
					}
					
					if(right){
						if(i < N - 1){
							nmap[i + 1][j - 1] -= 1;
						}
						if(i < N - 2){
							nmap[i + 2][j - 2] -= 1;
						}
					}
					else{
						if(j < M - 1){
							nmap[i - 1][j + 1] -= 2;
						}
						if(j < M - 2){
							nmap[i - 2][j + 2] -= 2;
						}
					}
				}
			}
		}
	}

	std::cout << ans << std::endl;

	return 0;
}
