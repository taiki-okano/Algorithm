#include <iostream>
#include <algorithm>
#include <limits>

using ll = long long;

constexpr ll MAX_N = 500000;
constexpr ll INF = std::numeric_limits<long long>::max();

struct data{
	ll s, max, min;	
};

data datas[MAX_N][MAX_N];
ll N;
ll A[MAX_N], B[MAX_N];

int main(){
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);

	std::cin >> N;

	for(int i = 0; i < N; ++i){
		std::cin >> A[i] >> B[i];
		datas[i][i] = data(B[i], A[i], A[i]);
	}

	return 0;
}

