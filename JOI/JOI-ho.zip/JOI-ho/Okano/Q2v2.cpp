#include <iostream>
#include <algorithm>
#include <limits>

using ll = long long;

constexpr ll MAX_N = 500000;
constexpr ll INF = std::numeric_limits<long long>::max();

ll N;
ll A[MAX_N], B[MAX_N];
ll dp[MAX_N], dpS[MAX_N], dpM[MAX_N], dpm[MAX_N];

ll dfs(ll n, ll max, ll min, ll S);

int main(){
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);

	std::cin >> N;

	for(ll i = 0; i < N; ++i){
		std::cin >> A[i] >> B[i];
	}

	for(int i = 0; i < N; ++i){
		dp[i] = B[i] - A[i];
		dpS[i] = B[i];
		dpM[i] = A[i];
		dpm[i] = A[i];
		for(int j = 0; j < i; ++j){
			ll s = dpS[j] + B[i], max = dpM[j], min = dpm[j];
			max = std::max(max, A[i]);
			min = std::min(min, A[i]);
			if(dp[i] < s - (max - min)){
				dp[i] = s - (max - min);
				dpS[i] = s;
				dpM[i] = max;
				dpm[i] = min;
			}
			else if(dp[i] < dp[j]){
				dp[i] = dp[j];
				dpS[i] = dpS[j];
				dpM[i] = dpM[j];
				dpm[i] = dpm[j];
			}
		}
		std::cout << dp[i] << std::endl;
	}

	std::cout << dp[N - 1] << std::endl;

	return 0;
}
