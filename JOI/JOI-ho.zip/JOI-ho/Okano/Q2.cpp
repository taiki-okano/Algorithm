#include <iostream>
#include <algorithm>
#include <limits>

using ll = long long;

constexpr ll MAX_N = 500000;
constexpr ll INF = std::numeric_limits<long long>::max();

ll N;
ll A[MAX_N], B[MAX_N];

ll dfs(ll n, ll max, ll min, ll S);

int main(){
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);

	std::cin >> N;

	for(ll i = 0; i < N; ++i){
		std::cin >> A[i] >> B[i];
	}

	std::cout << dfs(0, 0, INF, 0) << std::endl;

	return 0;
}

ll dfs(ll n, ll max, ll min, ll S){
	if(n == N){
		if(min == INF){
			return 0;
		}
		return S - (max - min);
	}

	ll nmax = max, nmin = min;
	if(A[n] > max){
		nmax = A[n];
	}
	if(A[n] < min){
		nmin = A[n];
	}

	ll res = std::max(
			dfs(n + 1, nmax, nmin, S + B[n]),
			dfs(n + 1, max, min, S)
			);

	return res;
}
