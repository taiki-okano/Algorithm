#include <iostream>
#include <string>
#include <vector>

constexpr int MAX_L = 20;

int main(){

	int L, Q;
	int p[MAX_L];
	std::string str;

	std::cin >> L >> Q >> str;

	for(int i = 0; i < int(str.size()); ++i){
		p[i] = (str[i] - '0');
	}

	for(int i = 0; i < Q; ++i){
		std::vector<int> list;
		for(int j = L; j > 0; --j){
			char input;
			std::cin >> input;
			if(input == '1'){
				for(auto &x : list){
					x = x + (1 << j);
				}
			}
		}

		int sum = 0;
		for(auto &x : list){
			std::cout << "DEBUG " << x << std::endl;
			sum += p[x];
		}
		std::cout << sum << std::endl;

	}


	return 0;
}
