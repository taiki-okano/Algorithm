#include <iostream>
#include <queue>
#include <cstdint>
#include <functional>

struct Edge {
	int64_t dist;
	int64_t cost;
};
std::vector<std::vector<Edge>> edges;

int64_t dijkstra(int s, int t, std::vector<int>& route) {
	std::vector<bool> visited(edges.size());
	std::vector<int> prev(edges.size());
	prev[s] = -1;
	
	using Pair = std::pair<int64_t, int>;
	std::priority_queue<Pair, std::vector<Pair>, std::greater<>> que;
	
	que.push({s, 0});
	while (!que.empty()) {
		auto top = que.top();
		que.pop();
		auto cost = top.first;
		auto cur = top.second;
		
		if (cur == t) {
			route.push_back(t);
			
			while (prev[cur] != -1)
				route.push_back(prev[cur]);
			
			std::cout << "hoge" << std::endl;
			return cost;
		}
		
		if (visited[cur])
			continue;
		
		visited[cur] = true;
		
		for (auto&& e : edges[cur]) {
			if (visited[e.dist])
				continue;
			
			prev[e.dist] = cur;
			que.push({ cost + e.cost, e.dist });
		}
	}
	
	return 1 << 30;
}

int main() {
	int n, m, s, t, u, v;
	std::cin >> n >> m >> s >> t >> u >> v;
	--s, --t, --u, --v;
	
	edges.resize(n);
	for (int i = 0; i < m; ++i) {
		int64_t a, b, c;
		std::cin >> a >> b >> c;
		--a, --b;
		
		edges[a].push_back({b, c});
		edges[b].push_back({a, c});
	}
	
	std::vector<int> route;
	dijkstra(s, t, route);
	
	for (int i = 0; i < route.size() - 1; ++i) {
		for (auto&& e : edges[i]) {
			if (e.dist == route[i + 1]) {
				e.cost = 0;
				break;
			}
		}
	}
		
	std::cout << dijkstra(u, v, route) << std::endl;
}
