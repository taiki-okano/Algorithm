#include <iostream>
#include <vector>
#include <cstdint>
#include <algorithm>

int main() {
	int n, k;
	std::cin >> n >> k;
	
	std::vector<int64_t> times(n);
	for (auto&& e : times)
		std::cin >> e;
		
	std::sort(times.begin(), times.end());
	
	int block = n;
	std::vector<int64_t> blanks;
	blanks.reserve(n);
	
	for (int i = 1; i < n; ++i) {
		if (times[i - 1] != times[i] - 1)
			blanks.push_back(times[i] - times[i - 1] - 1);
		else
			--block;
	}
	
	std::sort(blanks.begin(), blanks.end());
	block -= k;
	
	int64_t ans = n;
	for (int i = 0; i < block; ++i)
		ans += blanks[i];
		
	std::cout << ans << std::endl;
}
