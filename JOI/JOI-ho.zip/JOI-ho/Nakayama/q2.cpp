#include <iostream>
#include <cstdint>
#include <vector>
#include <algorithm>
#include <limits>

constexpr int64_t Inf = std::numeric_limits<int64_t>::max();

int main() {
	int64_t n;
	std::cin >> n;
	
	std::vector<std::pair<int64_t, int64_t>> ab(n);
	for (auto&& e : ab)
		std::cin >> e.first >> e.second;
	
	
	std::sort(ab.begin(), ab.end());
	
	auto diff = [&](int x) {
		return (x == n - 1 ? 0 : ab[x + 1].first - ab[x].first);
	};
	
	int64_t ans = 0;
	int64_t sum = 0, min = 0;
	for (int i = 0; i < n; ++i) {
		sum += ab[i].second;
		
		ans = std::max(ans, sum - std::min(min, sum));
		
		sum -= diff(i);
		min = std::min(min, sum);
	}
	
	std::cout << ans << std::endl;
}
