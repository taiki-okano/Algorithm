#include <iostream>
#include <algorithm>

constexpr int MaxN = 3000, MaxM = 3000;

int dp[MaxN][MaxM][3];

int field[MaxN][MaxM];

// 0: 縦, 1: 横
bool placable[MaxN][MaxM][2];

int n, m;

bool placed[MaxN][MaxM];
bool visited[MaxN][MaxM];
int dfs(int y, int x) {
	if (y < 0 || n <= y || x <= 0 || m <= x || visited[y][x])
		return 0;
	
	visited[y][x] = true;
	
	int ret = 0;
	if (placable[y][x][0]) {
		placed[y + 1][x] = placed[y + 2][x] = true;
		dfs(y + 1, x);
	}
}

int main() {
	std::cin >> n >> m;
	
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			char c;
			std::cin >> c;
			
			if (c == 'R')
				field[i][j] = 0;
			else if (c == 'G')
				field[i][j] = 1;
			else
				field[i][j] = 2;
		}
 	}
 	
 	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			if (field[i][j] != 0)
				continue;
			
			if (i < n - 2)
				placable[i][j][0] = field[i + 1][j] == 1 && field[i + 2][j] == 2;
			if (j < m - 2)
				placable[i][j][1] = field[i][j + 1] == 1 && field[i][j + 2] == 2;
		}
	}
}
