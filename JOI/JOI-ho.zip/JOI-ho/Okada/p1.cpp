#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
#define ll long long int 
#define rep(i,n) for(ll i=0;i<n;++i)
const ll n_max=100000;
int main(){
	ll v[n_max];
	ll n,k,ans;
	vector<ll>bitw;
	cin>>n>>k;
	rep(i,n){
		cin>>v[i];
		if(i==0)continue;
		bitw.push_back(v[i]-(v[i-1]+1));
		}
	sort(bitw.begin(),bitw.end());
	ans=v[n-1]-v[0]+1;
	for(ll i=(ll)bitw.size()-1;i>(ll)bitw.size()-1-(k-1);--i){
		ans-=bitw[i];
		}
	cout<<ans<<endl;
	}
