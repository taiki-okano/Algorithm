#include<iostream>
#include<algorithm>
#define ll long long
#define rep(i,n) for(ll i=0;i<n;++i)
#define pp pair<ll,ll>
using namespace std;
int main(){
	ll n;
	cin>>n;
	pp pps[500000];
	ll sums[500000];
	ll ans=0;
	rep(i,n)cin>>pps[i].first>>pps[i].second;
	sort(pps,pps+n);
	rep(i,n){
		if(i==0)sums[i]=pps[i].second;
		else sums[i]=sums[i-1]+pps[i].second;
		}
	for(ll l=0;l<n;++l){
		for(ll r=l;r<n;++r){
			ll dif=pps[r].first-pps[l].first;
			ans=max(ans,sums[r]-(l==0?0:sums[l-1])-dif);
		}
	}
	cout<<ans<<endl;
	return 0;
}
