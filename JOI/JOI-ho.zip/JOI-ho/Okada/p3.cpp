#include<iostream>
#define ll long long int
#define rep(i,n) for(ll i=0;i<n;++i)
#define pp pair<ll,ll>
#define ppp pair<ll,pair<ll,ll>>//S,max,min
using namespace std;
char in[3000][3000];
int ch[3000][3000]={};
int main(){
	int n,m,ans=0,ct=0;
	cin>>n>>m;
	rep(i,n)rep(j,m){
		int fl=0;
		cin>>in[i][j];
		if(in[i][j]=='W'){
			if(j>=2)if(in[i][j-1]=='G'&&in[i][j-2]=='R'){
				++ans;if(ch[i][j]!=0)++fl;else ch[i][j]++;
				if(ch[i][j-1]!=0)++fl;else ch[i][j-1]++;
				if(ch[i][j-2]!=0)++fl;else ch[i][j-2]++;
				}
			if(fl>0)++ct;
			fl=0;
			if(i>=2)if(in[i-1][j]=='G'&&in[i-2][j]=='R'){
				++ans;if(ch[i][j]!=0)++fl;else ch[i][j]++;
				if(ch[i-1][j]!=0)++fl;else ch[i-1][j]++;
				if(ch[i-2][j]!=0)++fl;else ch[i-2][j]++;
			}
			if(fl>0)++ct;
	}}
	cout<<ans-ct<<endl;
	return 0;
}
